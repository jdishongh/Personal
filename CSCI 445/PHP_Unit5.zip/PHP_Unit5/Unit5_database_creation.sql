USE jdishongh;
DROP TABLE IF EXISTS Customers;
DROP TABLE IF EXISTS Products;
DROP TABLE IF EXISTS Orders;

CREATE TABLE Customers(
    lastName VARCHAR(255),
    firstName VARCHAR(255),
    email VARCHAR(255),
    CONSTRAINT PRIMARY KEY (lastName,firstName)
);
CREATE TABLE Products(
    productName VARCHAR(255) NOT NULL,
    productImage VARCHAR(255) NOT NULL,
    price numeric(18,2),
    quantity int,
    itemsPerPound int,
    inactive boolean,
    CONSTRAINT PRIMARY KEY (productName)
);
CREATE TABLE Orders(
    orderNumber int NOT NULL AUTO_INCREMENT,
    customerLast VARCHAR(255),
    customerFirst VARCHAR(255),
    productName VARCHAR(255) NOT NULL,
    date datetime,
    quantity int,
    price numeric(18,2),
    tax numeric(18,2),
    donation numeric(18,2),
    total numeric(18,2),
    CONSTRAINT PRIMARY KEY (orderNumber),
    CONSTRAINT FOREIGN KEY (customerLast,customerFirst) References Customers(lastName,firstName),
    CONSTRAINT FOREIGN KEY (productName) References Products(productName)
);
INSERT INTO Customers (lastName,firstName,email)
VALUES ("Dishongh","Jason","jdishongh@mymail.mines.edu");

INSERT INTO Customers (lastName,firstName,email)
VALUES ("Doe","John","johndoe@gmail.com");

INSERT INTO Products(productName,productImage,price,quantity,itemsPerPound,inactive)
VALUES ("apple","apple.jpg","1.50","100","3",false);

INSERT INTO Products(productName,productImage,price,quantity,itemsPerPound,inactive)
VALUES ("orange","orange.jpg","1.50","60","3",false);

INSERT INTO Products(productName,productImage,price,quantity,itemsPerPound,inactive)
VALUES ("mango","mango.jpg","1.50","50","6",false);