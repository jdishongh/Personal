<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "jdishongh";
    
    // Create connection
    $conn = mysqli_connect($servername, $username, $password,$dbname);
    
    // Check connection
    if (!$conn) {
      die("Connection failed: " . mysqli_connect_error());
    }
    #echo "Connected successfully";

    $firstName = $_GET["firstname"];
    $lastName = $_GET["lastname"];

    $firstString = "$firstName%";
    $lastString = "$lastName%";

    $customerTest = "SELECT * FROM customers WHERE firstName LIKE ? AND lastName LIKE ?";

    $query = $conn->prepare($customerTest);
    $query->bind_param("ss",$firstString, $lastString);
    $query->execute();

    $customerResult = $query->get_result();
    
    if($customerResult->num_rows > 0){
        echo "<table id='name'><tr><th>First Name</th><th>Last Name</th><th>Email</th></tr>";

        while ($row = $customerResult->fetch_assoc()){
            echo "<tr><td id='highlight'>" . $row["firstName"] . "</td><td>" . $row["lastName"] . "</td><td>" . $row["email"] . "</td></tr>";
        }
        echo "</table>";
    }
    $query->close();
    ?>