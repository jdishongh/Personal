1. For Just Show Textbox include price in table
2. Incorporate a sort by date so what date the most orders occurred
3. An alternative method would be to implement the highlighting table rows and such
4. If the table gets too big it would be nice to implement graphs like bar charts to show quantity of orders per individual
5. Sort by total,quantity,price