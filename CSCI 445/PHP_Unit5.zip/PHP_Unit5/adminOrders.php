<?php
include "header.php"
?>
<body>
    <header>
        <h2>Orders</h2>
    </header>
    <div id="orderTables">
        <?php
        include "database.php";
        echo "<table id='startTable'><tr><th>Customer</th><th>Fruit</th><th>Date</th><th>Quantity</th><th>Price</th><th>Tax</th><th>Donation</th><th>Total</th></tr>";
        while($row = $startTable->fetch_assoc()){
            echo "<tr><td>" . $row["customerFirst"] . " " . $row["customerLast"] . "</td><td>" . $row["productName"] . "</td><td>" . $row["date"] . "</td><td>". $row["quantity"] . "</td><td>" . $row["price"]. "</td><td>" . $row["tax"] ."</td><td>" . $row["donation"]  . "</td><td>" . $row["total"] . "</td>";
        }
        echo "</table>";
        ?>
    </div>
    <header>
        <h2>Display Options</h2>
    </header>
    <div id="displayOrder">
        <form method="post" onsubmit="return false">
            <em>Sort By:</em><br>
            <input type="radio" id="customerOrderSort" name="sortResult" value="customerOrderSort"
            onclick="document.getElementById('fruitSort').value = ''; document.getElementById('customerSort').value = '';">
            <label for="customerOrderSort">Customer</label><br>

            <input type="radio" id="productOrderSort" name="sortResult" value="productOrderSort"
            onclick="document.getElementById('fruitSort').value = ''; document.getElementById('customerSort').value = '';">
            <label for="productOrderSort">Product</label><br>

            <em>Display Option:</em><br>
            <input type="checkbox" id="showTotals" name="showTotals" value="showTotals"
            onclick="document.getElementById('fruitSort').value = ''; document.getElementById('customerSort').value = '';">
            <label for="showTotals">Just Show Totals</label><br><br>
        
            <em>OR Filter by either:</em><br>   
            <select id="fruitSort" name="fruitSort"
            onchange="document.getElementById('customerOrderSort').checked=false; document.getElementById('productOrderSort').checked=false; document.getElementById('showTotals').checked = false;">
                <option value="" selected disabled hidden>--Select a Fruit--</option>
                    <?php
                    include "database.php";
                    if($productTable->num_rows > 0 ){
                        while($row = $productTable->fetch_assoc()){
                            echo '<option id="' . $row["productName"] . '" value="' . $row["productName"] . '">';
                            echo $row["productName"];
                            echo "</option>";
                        }
                    }
                    ?>
            </select>
            <p>OR</p>
            <select id="customerSort" name="customerSort"
            onchange="document.getElementById('customerOrderSort').checked=false; document.getElementById('productOrderSort').checked=false; document.getElementById('showTotals').checked = false;">
                <option value="" selected disabled hidden>--Select a Customer--</option>
                    <?php
                    include "database.php";
                    if($customerDropdown->num_rows > 0 ){
                        while($row = $customerDropdown->fetch_assoc()){
                            echo '<option id="' . $row["lastName"] . '" value="' . $row["firstName"] . ' ' . $row["lastName"] .'">';
                            echo $row["firstName"] . " " . $row["lastName"];
                            echo "</option>";
                        }
                    }
                    ?>
            </select>
            <br><br><br>
            <input id="sortSubmit" type="submit" value="Submit">
        </form>
    </div>
</body>

<?php
include "footer.php"
?>