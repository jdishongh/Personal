<?php
error_reporting(0);
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "jdishongh";
$conn = mysqli_connect($servername, $username, $password,$dbname);

// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
//echo "Connected successfully";

$sortResult = $_POST["sortResult"];
$showTotals = $_POST["showTotals"];
$fruitSort = $_POST["fruitSort"];
$customerSort = $_POST["customerTable"];

$first = "";
$last = "";

if($customerSort !== null){
    $firstLast = explode(" ",$customerSort);
    $first = $firstLast[0];
    $last = $firstLast[1];
}

$totalBoolean = false;

if($showTotals == false){
    $totalBoolean = true;
}

$sortingQuery = "";
if($sortResult !== NULL){
    if($sortResult == "customerOrderSort"){
        $sortingQuery = "SELECT * FROM orders ORDER BY customerLast,customerFirst";
    }
    elseif($sortResult == "productOrderSort"){
        $sortingQuery = "SELECT * FROM orders ORDER BY productName";
    }
    $queryTable = $conn->query($sortingQuery);

    if($queryTable->num_rows > 0){
        if($totalBoolean == true){
            echo "<table id='querySortTable'><tr><th>Customer</th><th>Quantity</th><th>Total</th></tr>";
            while($row = $queryTable->fetch_assoc()){
                echo "<tr><td>" . $row["customerFirst"] . " " . $row["customerLast"] . "</td><td>" . $row["quantity"] . "</td><td>" . $row["total"] . "</td>";
            }
            echo "</table>";
        }
        else{
            echo "<table id='querySortTable'><tr><th>Customer</th><th>Fruit</th><th>Date</th><th>Quantity</th><th>Price</th><th>Tax</th><th>Donation</th><th>Total</th></tr>";
            while($row = $queryTable->fetch_assoc()){
                echo "<tr><td>" . $row["customerFirst"] . " " . $row["customerLast"] . "</td><td>" . $row["productName"] . "</td><td>" . $row["date"] . "</td><td>". $row["quantity"] . "</td><td>" . $row["price"]. "</td><td>" . $row["tax"] ."</td><td>" . $row["donation"]  . "</td><td>" . $row["total"] . "</td>";
            }
            echo "</table>";
        }
    }
}
if ($fruitSort !== NULL || $customerSort !== NULL){
    if($fruitSort != NULL && $customerSort == NULL){
        $sortingQuery = "SELECT * FROM orders WHERE productName=?";
        $query = $conn->prepare($sortingQuery);
        $query->bind_param("s",$fruitSort);
        $query->execute();
        $queryTable = $query->get_result();
    }
    elseif($fruitSort == NULL && $customerSort != NULL){
        $sortingQuery = "SELECT * FROM orders WHERE customerLast=? AND customerFirst=?";
        $query = $conn->prepare($sortingQuery);
        $query->bind_param("ss",$last,$first);
        $query->execute();
        $queryTable = $query->get_result();
    }
    elseif($fruitSort != NULL && $customerSort != NULL){
        $sortingQuery = "SELECT * FROM orders WHERE productName=? AND customerLast=? AND customerFirst=?";
        $query = $conn->prepare($sortingQuery);
        $query->bind_param("sss",$fruitSort,$last,$first);
        $query->execute();
        $queryTable = $query->get_result();
    }
    if($queryTable->num_rows > 0){
        echo "<table id='querySortTable'><tr><th>Customer</th><th>Fruit</th><th>Date</th><th>Quantity</th><th>Price</th><th>Tax</th><th>Donation</th><th>Total</th></tr>";
        while($row = $queryTable->fetch_assoc()){
            echo "<tr><td>" . $row["customerFirst"] . " " . $row["customerLast"] . "</td><td>" . $row["productName"] . "</td><td>" . $row["date"] . "</td><td>". $row["quantity"] . "</td><td>" . $row["price"]. "</td><td>" . $row["tax"] ."</td><td>" . $row["donation"]  . "</td><td>" . $row["total"] . "</td>";
        }
        echo "</table>";
    }
} 
?>