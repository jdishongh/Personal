<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "food";
    
    // Create connection
    $conn = mysqli_connect($servername, $username, $password,$dbname);
    
    // Check connection
    if (!$conn) {
      die("Connection failed: " . mysqli_connect_error());
    }
    #echo "Connected successfully";

    $firstName= $_POST["firstname"];
    $lastName = $_POST["lastname"];
    $email = $_POST["email"];
    $quantity = $_POST["quantity"];
    $fruit = $_POST["fruit"];

    $customerQuery = "SELECT * FROM customers WHERE lastName=? AND firstName=?";
    $query = $conn->prepare($customerQuery);
    $query->bind_param("ss",$_POST["lastname"], $_POST["firstname"]);
    $query->execute();
    $customerQueryResult = $query->get_result();
    $customer = "";

    if($customerQueryResult->num_rows > 0){
        $customer = $customerQueryResult->fetch_assoc();
    }

    if($customer == ""){
        $newCustomer = "INSERT INTO Customers (lastName,firstName,email) VALUES (?,?,?);";
        $query = $conn->prepare($newCustomer);
        $query->bind_param("sss",$lastName, $firstName, $email);
        $query->execute();
    }else{
        
    }


    $priceQuery ="SELECT price, quantity FROM products WHERE productName=?";
    $query = $conn->prepare($priceQuery);
    $query->bind_param("s",$fruit);
    $query->execute();
    $priceValue = $query->get_result();
    $priceValue = $priceValue->fetch_assoc();

    $price = $priceValue["price"];
    $stockValue = $priceValue["quantity"];

    $subtotal = $price * $quantity;
    $taxTotal = $subtotal * 1.04;
    $taxValue = $taxTotal - $subtotal;
    $totalCost = $taxTotal;


    if(empty($_POST["yes"])){

    }else{
        $totalCost = ceil($taxTotal);

    }
    #$donation = $totalCost  - $taxTotal;
    $donation = 0;
    
    $date = date('Y-m-d H:i:s');
    $newOrder = "INSERT INTO orders (customerID,productName,date,quantity,price,tax,donation,total) VALUES (?,?,?,?,?,?,?,?)";
    $query = $conn->prepare($newOrder);
    $query->bind_param("sssidddd",$customer["id"], $fruit, $date, $quantity,$subtotal,$taxValue,$donation,$totalCost);
    $query->execute();
    
    echo "Form has been submitted successfully!!";

    $stockValue = $stockValue - $quantity;
    if ($stockValue < 0){
        $stockValue = 0;
    }
    $updateStock = "UPDATE products SET quantity=? WHERE productName=?";
    $query = $conn->prepare($updateStock);
    $query->bind_param("is",$stockValue,$fruit);
    $query->execute();

    $query->close();
    ?>