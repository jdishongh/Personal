$(document).ready(function(){
    
    $("#fruit").change(function(){
        var imageId = "#" + this.value;
        $("#available").val($(imageId).attr("data-left"));
     });
    
    $("#submit").click(function(){
        var firstName = $("#firstname").val();
        var lastName = $("#lastname").val();
        var email = $("#email").val();
        var quantity = $("#quantity").val();
        var fruit = $("#fruit").val();

        var dataString = "firstname=" + firstName + "&lastname=" + lastName + "&email=" + email + "&quantity=" + quantity + "&fruit=" + fruit;
        console.log(dataString);
        $.ajax({
            type: "POST",
            url: "Unit3_ajaxsubmit.php",
            data: dataString,
            cache: false,
            success: function(result){
                $("#orderStatus").text(result);
                //alert(result);
            }
        });
    });
    $(".nameTable").keyup(function(){
        var firstName = $("#firstname").val();
        var lastName = $("#lastname").val();
        if(firstName== "" && lastName== ""){
            $("#aside").html("<p>No Suggestions</p>");
            return;
        }else{
            var xmlhttp = new XMLHttpRequest();
            xmlhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    $("#aside").html(this.responseText);
                    highlight_row();
                }
            };
            xmlhttp.open("GET","Unit3_get_customer_table.php?firstname="+firstName+"&lastname="+lastName,true);
            xmlhttp.send();
        }
    });
});
function highlight_row() {
    var table = document.getElementById('name');
    var cells = table.getElementsByTagName('td');

    for (var i = 0; i < cells.length; i++) {
        // Take each cell
        var cell = cells[i];
        // do something on onclick event for cell
        cell.onclick = function () {
            // Get the row id where the cell exists
            var rowId = this.parentNode.rowIndex;

            var rowsNotSelected = table.getElementsByTagName('tr');
            for (var row = 0; row < rowsNotSelected.length; row++) {
                rowsNotSelected[row].style.backgroundColor = "";
                rowsNotSelected[row].classList.remove('selected');
            }
            var rowSelected = table.getElementsByTagName('tr')[rowId];
            rowSelected.style.backgroundColor = "pink";
            rowSelected.className += " selected";
            $("#firstname").val(rowSelected.cells[0].innerHTML);
            $("#lastname").val(rowSelected.cells[1].innerHTML);
            $("#email").val(rowSelected.cells[2].innerHTML);
        }
    }

}