<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "jdishongh";

// Create connection
$conn = mysqli_connect($servername, $username, $password,$dbname);

// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
#echo "Connected successfully";

$fruitName= $_POST["fruitName"];
$fruitImage = $_POST["fruitImage"];
$fruitPerPound = $_POST["perPound"];
$fruitQuantity = $_POST["fruitQuantity"];
$fruitPrice = $_POST["fruitPrice"];
$fruitStatus = isset($_POST["fruitInactive"]);

$fruitButton = $_POST["fruitValue"];

echo $fruitButton;
if($fruitButton =="Add Fruit"){
    //insert
    $fruitQuery ="INSERT INTO Products(productName,productImage,price,quantity,itemsPerPound,inactive) VALUES (?,?,?,?,?,?)";
    $query = $conn->prepare($fruitQuery);
    $query->bind_param("ssdiii",$fruitName,$fruitImage,$fruitPrice,$fruitQuantity,$fruitPerPound,$fruitStatus);
    $query->execute();

}else if($fruitButton =="Update"){
    //update
    $fruitQuery ="UPDATE Products SET productName=?,productImage=?,price=?,quantity=?,itemsPerPound=?,inactive=?";
    $query = $conn->prepare($fruitQuery);
    $query->bind_param("ssssss",$fruitName,$fruitImage,$fruitPrice,$fruitQuantity,$fruitPerPound,$fruitStatus);
    $query->execute();

}else if($fruitButton =="Delete"){
    //delete
    $fruitQuery ="DELETE FROM Products WHERE productName=?";
    $query = $conn->prepare($fruitQuery);
    $query->bind_param("s",$fruitName);
    $query->execute();
    
    /*$productQuery = "Select * FROM orders WHERE productName=?";
    $query = $conn->prepare($productQuery);
    $query->bind_param("s",$fruitName);
    $query->execute();

    if($query->num_rows > 0 ){
        echo "Can't delete, there are existing orders for this fruit";
    }
    else{
        $fruitQuery ="DELETE FROM Products WHERE productName=?";
        $query = $conn->prepare($fruitQuery);
        $query->bind_param("s",$fruitName);
        $query->execute();
    }*/
}
?> 