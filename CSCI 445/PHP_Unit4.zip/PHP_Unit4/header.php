<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="author" content="Jason Dishongh">
    <link rel="stylesheet" type="text/css" href="store.css" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="script.js"></script>
    <title>Joker's Store</title>
</head>

<nav class="topnav" id="myTopnav"> 
    <a href="adminProduct.php">Products</a>
    <a href="">Orders</a>
    <a href="">Customers</a>
    <a href="admin.php">Lists</a>
    <a href="store.php">Order Processing</a>
</nav>
<br><br>

<div class="webHeader">
    <header>
        <h1>Welcome to Joker's Store</h1>
    </header>
    <p font-style="italic">If you want a lower price, go somewhere else!!</p>
</div>
