<?php
    include 'header.php';
?>
<body>
    <main>
        <form method="post" onsubmit="return false">
            <header>
                <h2>Personal Information</h1>
            </header>
            <div class="personal" id="personal">
                <label for="firstname">First Name:<span class="required-field"></span></label><br>
                <input type="text" id="firstname" class="nameTable" name="firstname"
                pattern = "[A-Za-z ']*" title = "Names can only include letters, spaces and apostrophe" required><br>
                <label for="lastname">Last Name:<span class="required-field"></span></label><br>
                <input type="text" id="lastname" class="nameTable" name="lastname"
                pattern="[A-Za-z ']*" title="Names can only include letters, spaces and apostrophe" required><br>
                <label for="email">Email:<span class="required-field"></span></label><br>
                <input type="email" id="email" name="email" title="Email needs to include an @." required><br>
            </div>
            <aside id="aside">
            </aside>
            <header>
                <h2>Product Information</h1>
            </header>
            <div class="product" id="product">
                <label for="fruit">Fruit:</label><br>
                <select id="fruit" name="fruit" required>
                    <option value="" selected disabled hidden>--Select a Fruit--</option>
                    <?php
                        include "database.php";

                        if($productTable->num_rows > 0 ){
                            #print("test");
                            while($row = $productTable->fetch_assoc()){
                                if($row["inactive"] == 0){
                                    echo '<option id="' . $row["productName"] . '" value="' . $row["productName"] . '" data-left="' . $row["quantity"] . '">';
                                    echo $row["productName"] . " - " . $row["price"] . " - " . $row["itemsPerPound"];
                                    echo "</option>";
                                }
                            }
                        }
                    ?>
                </select>
                <br><br>
                <label for="available">Available:</label>
                <input type="text" id="available" name="available" readonly><br><br>
                <label for="quantity">Quantity:</label>
                <input type="text" id="quantity" name="quantity"
                pattern="^[1-9][0-9]?$|^100$" title="Quantity needs to be between 1 and 100."><br>
            </div>
            <br>
            <br>
            <input id="submit" type="submit" value="Purchase">
            <input id="reset" type="reset" value="Reset">
        </form>
        <p id="orderStatus"></p>
    </main>
</body>
<?php
include 'footer.php';
?>