<?php
    include 'header.php';
?>
<body>
    <script>
        function validationForm(){
            var name = document.forms["myForm"]["fruitName"].value;
            if (name == "") {
                document.getElementById("fruitMessage").innerHTML = "Name should not be empty!";
                document.forms["myForm"]["fruitName"].focus();
                return false;
            }
            var image = document.forms["myForm"]["fruitImage"].value;
            if(image==""){
                document.getElementById("fruitMessage").innerHTML = "Image should not be empty!";
                document.forms["myForm"]["fruitImage"].focus();
                return false;
            }
            var itemPer = document.forms["myForm"]["perPound"].value;
            if(itemPer==""){
                document.getElementById("fruitMessage").innerHTML = "Items Per Pound should not be empty!";
                document.forms["myForm"]["perPound"].focus();
                return false;
            }
        }
    </script>
    <main>
        <div id="fruitDiv">
            <header>
                <h2>Fruit<h2>
            </header>
            <?php
                include "database.php";

                if($productTable->num_rows > 0){
                    echo "<table id='fruitTable'><tr><th>Name</th><th>Image</th><th>Items Per Pound</th><th>Quantity</th><th>Price</th><th>Inactive</th></tr>";
                    while($row = $productTable->fetch_assoc()){
                        echo "<tr><td>" . $row["productName"] . "</td><td>" . $row["productImage"] . "</td><td>" . $row["itemsPerPound"] . "</td><td>" . $row["quantity"] . "</td><td>" . $row["price"] . "</td><td>" . $row["inactive"] . "</td>";
                    }
                    echo "</table>";
                }
            ?>
        </div>
        <div id="fruitForm">
        <form method="post" onsubmit="return validationForm()" name="myForm">
            <header>
                <h2>Fruit Information</h1>
            </header>
            <p id="fruitMessage"></p>
            <div class="fruitInfo" id="fruitInfo">
                <label for="fruitName">Fruit Name:<span class="required-field"></span></label>
                <input type="text" id="fruitName" class="nameTable" name="fruitName" 
                pattern="[A-Za-z ']*" title="Names can only include letters, spaces and apostrophes."required><br><br>
                <label for="fruitImage">Fruit Image:<span class="required-field"></span></label>
                <input type="text" id="fruitImage" class="nameTable" name="fruitImage" required
                ><br><br>
                <label for="perPound">Items Per Pound:<span class="required-field"></span></label>
                <input type="number" id="perPound" name="perPound" min="1" max="1000000"required><br><br>
                <label for="fruitQuantity">Quantity:</label>
                <input type="number" id="fruitQuantity" name="fruitQuantity" min="0" max="1000000"><br><br>
                <label for="fruitPrice">Price:</label>
                <input type="number" id="fruitPrice" name="fruitPrice" pattern="[0-9]+([\.,][0-9]+)?" step="0.01"><br><br>
                <label for="fruitInactive">Inactive</label>
                <input type="checkbox" id="fruitInactive" name="fruitInactive">
                <br>
            </div>
            <input class="fruitCrud" type="submit" value="Add Fruit" name="fruitValue">
            <input class="fruitCrud" type="submit" value="Update" name="fruitValue">
            <input class="fruitCrud" type="submit" value="Delete" name="fruitValue">
            <br>
        </form>
        </div>
    </main>
</body>
<?php
include 'footer.php';
?>