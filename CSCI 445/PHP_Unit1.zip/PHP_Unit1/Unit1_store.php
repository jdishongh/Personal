<?php
    include 'Unit1_header.php';
?>
<body>
    <main>
        <form action="Unit1_process_order.php" method="post">
            <header>
                <h2>Personal Information</h1>
            </header>
            <div class="personal" id="personal">
                <label for="firstname">First Name:<span class="required-field"></span></label><br>
                <input type="text" id="firstname" name="firstname"
                pattern = "[A-Za-z ']*" title = "Names can only include letters, spaces and apostrophe" required><br>
                <label for="lastname">Last Name:<span class="required-field"></span></label><br>
                <input type="text" id="lastname" name="lastname"
                pattern="[A-Za-z ']*" title="Names can only include letters, spaces and apostrophe" required><br>
                <label for="email">Email:<span class="required-field"></span></label><br>
                <input type="email" id="email" name="email" title="Email needs to include an @." required><br>
            </div>
            <header>
                <h2>Product Information</h1>
            </header>
            <div class="product" id="product">
                <label for="fruit">Fruit:</label><br>
                <select id="fruit" name="fruit" onchange = "changeImage(this.value)" required>
                    <option value="" selected disabled hidden>--Select a Fruit--</option>
                    <option value="apple">Apple-3 fruits-$1.50/lb</option>
                    <option value="orange">Orange-3 fruits-$1.50/lb</option>
                    <option value="mango">Mango-6 fruits-$1.50/lb</option>
                </select>
                <br><br>
                <label for="quantity">Quantity:</label>
                <input type="text" id="quantity" name="quantity"
                pattern="^[1-9][0-9]?$|^100$" title="Quantity needs to be between 1 and 100."><br>
            </div>
            <img id="fruitPicture"  float="right">
            <header>
                <h2>Donation</h1>
            </header>
            <div class="donation" id="donation">
                <p>Round up to nearest dollar for Donation?</p>
                <input type="radio" id="yes" name="yes">
                <label for="yes">Yes</label>
                <input type="radio" id="no" name="no">
                <label for="no">No</label>
            </div>
            <br><br>
            <input type="submit" value="Purchase">
        </form>
    </main>
    <script>
        function changeImage(value){
            var srcName = "images/" + value + ".jpg";
            $("#fruitPicture").attr("src",srcName).css("visibility","visibile");
        }
    </script>
</body>
<?php
include 'Unit1_footer.php';
?>