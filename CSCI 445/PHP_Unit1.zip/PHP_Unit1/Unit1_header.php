<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="author" content="Jason Dishongh">
    <link rel="stylesheet" type="text/css" href="Unit1_store.css" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <title>Joker's Store</title>
</head>

<nav class="topnav" id="myTopnav"> 
    <a href="Unit1_store.php">Home</a>
    <a href="Unit1_store.php">Fruits</a>
    <a href="Unit1_store.php">Vegetables</a>
</nav>
<br><br>

<div class="webHeader">
    <header>
        <h1>Welcome to Joker's Store</h1>
    </header>
    <p font-style="italic">If you want a lower price, go somewhere else!!</p>
</div>
