<br><br>
<footer>
    <header>
        <h2>If you want better prices try King Soopers!!</h2>
    </header>
    <p>Contact us: TooExpensive@foryou.com</p>
</footer>
</html>