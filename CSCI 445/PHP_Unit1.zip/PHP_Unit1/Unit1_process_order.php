<html>
<head>
    <?php
    include 'Unit1_header.php';
    ?>
</head>
<body>
    <?php
    $fruitType = $_POST["fruit"];
    $fruitType = explode("-",$fruitType);
    $quantity = $_POST["quantity"];
    $price = 1.50;
    $taxTotal = $price * 1.04;


    echo "Thank you for your order, " . $_POST["firstname"] . " " . $_POST["lastname"] . " (". $_POST["email"]. ")<br>";
    echo "You have selected " . $quantity . " " . $fruitType[0] . "(s)."  . "<br>";
    echo "Subtotal: $" . $price  . "<br>";
    echo "Total including tax: $". $taxTotal  . "<br>";

    if(empty($_POST["yes"])){

    }else{
        echo "Total with donation: $" . ceil($taxTotal);
    }
    
    ?>
</body>
<?php
    include 'Unit1_footer.php';
?>