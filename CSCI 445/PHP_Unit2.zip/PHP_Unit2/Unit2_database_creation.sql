CREATE TABLE Customers(
    id int NOT NULL AUTO_INCREMENT,
    lastName VARCHAR(255),
    firstName VARCHAR(255),
    email VARCHAR(255),
    CONSTRAINT PRIMARY KEY (id)
);
CREATE TABLE Products(
    productName VARCHAR(255) NOT NULL,
    price numeric(18,2),
    quantity int,
    itemsPerPound int,
    CONSTRAINT PRIMARY KEY (productName)
);
CREATE TABLE Orders(
    orderNumber int NOT NULL AUTO_INCREMENT,
    customerID int NOT NULL,
    productName VARCHAR(255) NOT NULL,
    date datetime,
    quantity int,
    price numeric(18,2),
    tax numeric(18,2),
    donation numeric(18,2),
    total numeric(18,2),
    CONSTRAINT PRIMARY KEY (orderNumber),
    CONSTRAINT FOREIGN KEY (customerID) References Customers(id),
    CONSTRAINT FOREIGN KEY (productName) References Products(productName)
);
INSERT INTO Customers (lastName,firstName,email)
VALUES ("Dishongh","Jason","jdishongh@mymail.mines.edu");

INSERT INTO Customers (lastName,firstName,email)
VALUES ("Doe","John","johndoe@gmail.com");

INSERT INTO Products(productName,price,quantity,itemsPerPound)
VALUES ("apple","1.50","0","3");

INSERT INTO Products(productName,price,quantity,itemsPerPound)
VALUES ("orange","1.50","9","3");

INSERT INTO Products(productName,price,quantity,itemsPerPound)
VALUES ("mango","1.50","50","6");