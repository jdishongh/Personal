<?php
    include 'Unit2_header.php';
?>
<body>
    <main>
        <form action="Unit2_process_order.php" method="post">
            <header>
                <h2>Personal Information</h1>
            </header>
            <div class="personal" id="personal">
                <label for="firstname">First Name:<span class="required-field"></span></label><br>
                <input type="text" id="firstname" name="firstname"
                pattern = "[A-Za-z ']*" title = "Names can only include letters, spaces and apostrophe" required><br>
                <label for="lastname">Last Name:<span class="required-field"></span></label><br>
                <input type="text" id="lastname" name="lastname"
                pattern="[A-Za-z ']*" title="Names can only include letters, spaces and apostrophe" required><br>
                <label for="email">Email:<span class="required-field"></span></label><br>
                <input type="email" id="email" name="email" title="Email needs to include an @." required><br>
            </div>
            <header>
                <h2>Product Information</h1>
            </header>
            <div class="product" id="product">
                <label for="fruit">Fruit:</label><br>
                <select id="fruit" name="fruit" onchange = "changeImage(this.value)" required>
                    <option value="" selected disabled hidden>--Select a Fruit--</option>
                    <?php
                        include "Unit2_database.php";

                        if($productTable->num_rows > 0 ){
                            print("test");
                            while($row = $productTable->fetch_assoc()){
                                echo '<option id="' . $row["productName"] . '" value="' . $row["productName"] . '" data-left="' . $row["quantity"] . '">';
                                echo $row["productName"] . " - " . $row["price"] . " - " . $row["itemsPerPound"];
                                echo "</option>";
                            }
                        }
                    ?>
                </select>
                <br><br>
                <label for="quantity">Quantity:</label>
                <input type="text" id="quantity" name="quantity"
                pattern="^[1-9][0-9]?$|^100$" title="Quantity needs to be between 1 and 100."><br>
            </div>
            <br>
            <img id="fruitPicture">
            <p id="remaining" float="right"></p>
            <header>
                <h2>Donation</h1>
            </header>
            <div class="donation" id="donation">
                <p>Round up to nearest dollar for Donation?</p>
                <input type="radio" id="yes" name="yes">
                <label for="yes">Yes</label>
                <input type="radio" id="no" name="no">
                <label for="no">No</label>
            </div>
            <br><br>
            <input type="submit" value="Purchase">
        </form>
    </main>
    <script>
        function changeImage(value){
            var imageId = "#" + value;
            var srcName = "images/" + value + ".jpg";
            $("#fruitPicture").attr("src",srcName).css("visibility","visible");
            console.log($(imageId).attr("data-left"));
            if($(imageId).attr("data-left") == 0){
                $("#remaining").text("Out of Stock");
            }else if($(imageId).attr("data-left") <= 10){
                $("#remaining").text("Only " + $(imageId).attr("data-left") + " left!");
            }else{
                $("#remaining").text("");
            }
        }
    </script>
</body>
<?php
include 'Unit2_footer.php';
?>