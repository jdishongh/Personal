<html>
<head>
    <?php
    include 'Unit2_header.php';
    ?>
</head>
<body>
    <div id="order">
    <?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "food";
    
    // Create connection
    $conn = mysqli_connect($servername, $username, $password,$dbname);
    
    // Check connection
    if (!$conn) {
      die("Connection failed: " . mysqli_connect_error());
    }
    #echo "Connected successfully";

    $customerQuery = "SELECT * FROM customers WHERE lastName=? AND firstName=?";
    $query = $conn->prepare($customerQuery);
    $query->bind_param("ss",$_POST["lastname"], $_POST["firstname"]);
    $query->execute();
    $customerQueryResult = $query->get_result();
    $customer = "";

    if($customerQueryResult->num_rows > 0){
        $customer = $customerQueryResult->fetch_assoc();
    }

    if($customer == ""){
        echo "Welcome ". $_POST["firstname"] . " " . $_POST["lastname"] . "<br>";
        echo "Thank you for your order, " . $_POST["firstname"] . " " . $_POST["lastname"] . " (". $_POST["email"]. ")<br>";
        $newCustomer = "INSERT INTO Customers (lastName,firstName,email) VALUES (?,?,?);";
        $query = $conn->prepare($newCustomer);
        $query->bind_param("sss",$_POST["lastname"], $_POST["firstname"], $_POST["email"]);
        $query->execute();
    }else{
        echo "Welcome Back!<br>";
        echo "Thank you for your order, " . $customer["firstName"] . " " . $customer["lastName"] . " (". $customer["email"]. ")<br>";
    }

    $fruitType = $_POST["fruit"];
    $quantity = $_POST["quantity"];

    $priceQuery ="SELECT price, quantity FROM products WHERE productName=?";
    $query = $conn->prepare($priceQuery);
    $query->bind_param("s",$fruitType);
    $query->execute();
    $priceValue = $query->get_result();
    $priceValue = $priceValue->fetch_assoc();
    $price = $priceValue["price"];
    $stockValue = $priceValue["quantity"];

    $subtotal = $price * $quantity;
    $taxTotal = $subtotal * 1.04;
    $taxValue = $taxTotal - $subtotal;
    $totalCost = $taxTotal;

    echo "You have selected " . $quantity . " " . $fruitType . "(s)."  . "<br>";
    echo "Subtotal: $" . $subtotal  . "<br>";
    echo "Total including tax: $". $taxTotal  . "<br>";

    if(empty($_POST["yes"])){

    }else{
        echo "Total with donation: $" . ceil($taxTotal);
        $totalCost = ceil($taxTotal);

    }
    $donation = $totalCost  - $taxTotal;
    
    $date = date('Y-m-d H:i:s');
    $newOrder = "INSERT INTO orders (customerID,productName,date,quantity,price,tax,donation,total) VALUES (?,?,?,?,?,?,?,?)";
    $query = $conn->prepare($newOrder);
    $query->bind_param("sssidddd",$customer["id"], $fruitType, $date, $quantity,$subtotal,$taxValue,$donation,$totalCost);
    $query->execute();

    $stockValue = $stockValue - $quantity;
    if ($stockValue < 0){
        $stockValue = 0;
    }
    $updateStock = "UPDATE products SET quantity=? WHERE productName=?";
    $query = $conn->prepare($updateStock);
    $query->bind_param("is",$stockValue,$fruitType);
    $query->execute();

    $query->close();
    ?>
    </div>
</body>
<?php
    include 'Unit2_footer.php';
?>